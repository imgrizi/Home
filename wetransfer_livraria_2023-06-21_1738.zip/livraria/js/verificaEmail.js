function verificaEmail() {
    console.log('Entrei verifica Email');

    email_a_pesquisar = $('input[name=emai]').val();

    console.log(email_a_pesquisar);

    $.

    ;

}
