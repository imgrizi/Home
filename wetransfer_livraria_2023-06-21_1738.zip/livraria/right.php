<h2><span>catergorias</span></h2>
    		<ul>
    			<li><a href="#">Arte </a></li>
    			<li><a href="#">Arquitectura</a></li>
    			<li><a href="#">Cinema</a></li>
    			<li><a href="#">Design</a></li>
          <li><a href="#">Fotografia</a></li>
    			<li><a href="#">Revistas</a></li>
    		</ul>  
            
     		<h2><span>Top de vendas</span></h2> 
        <ol> 
          <li> 
            <a href="#">Obras-primas da Arte Portuguesa - Arquitectura</a> 
            <div class="author">Maria De Lurdes Craveiro</div>          </li> 
          <li> 
            <a href="#">Obras-primas da Arte Portuguesa - Século Xx - Artes Visuais</a> 
            <div class="author">Delfim Sardo</div>          </li> 
          <li> 
            <a href="#">Obras-primas da Arte Portuguesa - Escultura</a> 
            <div class="author">Joaquim Oliveira Caetano</div>          </li> 
          <li> 
            <a href="#">Deus e Caravaggio</a> 
            <div class="author">Carlos Vidal</div>          </li> 
          <li> 
            <a href="#">Whispering Paper (The)</a> 
            <div class="author">Pedro Cabrita Reis</div>          </li> 
          <li> 
            <a href="#">100 Ideias Para o Design de Apartamentos</a> 
            <div class="author">Ana G. Cañizares</div>          </li> 
          <li> 
            <a href="#">Obras-primas da Arte Portuguesa - Pintura</a> 
            <div class="author">Paula Rodrigues</div>          </li> 
          <li> 
            <a href="#">Famous Faces</a> 
            <div class="author">Takkoda</div>          </li> 
          <li> 
            <a href="#">Primitivos - El Siglo Dorado de la Pintura Portuguesa</a>
            <div class="author">Paula Rodrigues</div>  
                      </li> 
          <li> 
            <a href="#">Vestígios Traces</a> 
            <div class="author">Luís Campos</div>          </li> 
        </ol> 
        <div>
        </div>
