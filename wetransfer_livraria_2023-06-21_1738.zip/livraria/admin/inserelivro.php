<?php
    $titulo = $_POST['titulo'];
    $titulo = $_POST['preco'];
    $titulo = $_POST['stock'];
    $titulo = $_POST['descricao'];
    $titulo = $_POST['editora'];

    $capa = $_FILES['capa'];

    print_r($capa);
    $origem = $capa['tmp_name'];
    
    //$nome_unico = uniqid();
    $nome_do_ficheiro = uniqid().".jpg";
    $nome_do_ficheiro = "imagem_inserida.jpg";
    $destino ="../imagens/".$nome_ficheiro;

    move_uploaded_file($origem,$destino)
?>

<!--explode()-->