<?php
 $ligacao = mysqli_connect('localhost','root','', 'livraria');
 ?>