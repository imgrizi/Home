<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="en">
<head>
<title>Livraria Curso PHP</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="description" content="">
<meta name="keywords" content="">
<link rel="stylesheet" href="css/style.css" type="text/css" />
</head>
<body>
<div id="container">
	<div id="header">

    <div id="navigation"> 
    	 <div id="menu-container"> 
            <ul>  
            	<li><a href="#">Livraria Online</a></li>          
              <li><a href="#">Home<span>Ir para a homepage</span></a></li> 
              <li><a href="#">Livraria<span>procure um livro</span></a></li> 
              <li><a href="#">Serviços<span>conheça os nossos serviços</span></a></li> 
                
              <li><a href="#">Sobre nós<span>saiba mais sobre  nós</span></a></li> 
              <li><a href="#">Contactos<span>contacte a livraria</span></a></li>                              
            </ul>
        </div>

        <div class="clear"></div>                   
    </div>

	</div>

	<div id="wrap">
    	<div id="navcontainer">sidebar </div>
    	
      <div id="content">
    		<h1>h1 titulo</h1>                   

            <p>Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis fauc</p> 
            <h2>h2 titulo</h2>
            <h3>H3 titulo</h3> 
            <h4>H4 titulo</h4> 
            <p><b>paragrafo a bold</b></p>  
            <ul> 
              <li>listas simples</li> 
              <li>listas simples</li> 
              <li>listas simples</li> 
              <li>listas simples</li> 
            </ul> 

    	</div>


    	<div id="subcontent">
    		<h2><span>catergorias</span></h2>
    		<ul>
    			<li><a href="#">Arte </a></li>
    			<li><a href="#">Arquitectura</a></li>
    			<li><a href="#">Cinema</a></li>
    			<li><a href="#">Design</a></li>
          <li><a href="#">Fotografia</a></li>
    			<li><a href="#">Revistas</a></li>
    		</ul>  
            
     		<h2><span>Top de vendas</span></h2> 
        <ol> 
          <li> 
            <a href="#">Obras-primas da Arte Portuguesa - Arquitectura</a> 
            <div class="author">Maria De Lurdes Craveiro</div>          </li> 
          <li> 
            <a href="#">Obras-primas da Arte Portuguesa - Século Xx - Artes Visuais</a> 
            <div class="author">Delfim Sardo</div>          </li> 
          <li> 
            <a href="#">Obras-primas da Arte Portuguesa - Escultura</a> 
            <div class="author">Joaquim Oliveira Caetano</div>          </li> 
          <li> 
            <a href="#">Deus e Caravaggio</a> 
            <div class="author">Carlos Vidal</div>          </li> 
          <li> 
            <a href="#">Whispering Paper (The)</a> 
            <div class="author">Pedro Cabrita Reis</div>          </li> 
          <li> 
            <a href="#">100 Ideias Para o Design de Apartamentos</a> 
            <div class="author">Ana G. Cañizares</div>          </li> 
          <li> 
            <a href="#">Obras-primas da Arte Portuguesa - Pintura</a> 
            <div class="author">Paula Rodrigues</div>          </li> 
          <li> 
            <a href="#">Famous Faces</a> 
            <div class="author">Takkoda</div>          </li> 
          <li> 
            <a href="#">Primitivos - El Siglo Dorado de la Pintura Portuguesa</a>
            <div class="author">Paula Rodrigues</div>  
                      </li> 
          <li> 
            <a href="#">Vestígios Traces</a> 
            <div class="author">Luís Campos</div>          </li> 
        </ol> 
        <div>
        </div>


      </div>

    
    	<div id="footer">
    		<p>footer.</p>
    	</div>
  </div>
</div>
</body>
</html>